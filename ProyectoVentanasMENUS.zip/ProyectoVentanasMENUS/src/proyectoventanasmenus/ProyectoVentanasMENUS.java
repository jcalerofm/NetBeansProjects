

package proyectoventanasmenus;


public class ProyectoVentanasMENUS {

   
    public static void main(String[] args) {
        MenuVentanas p = new MenuVentanas();
        p.setLocationRelativeTo(null);
        p.setResizable(false);
        p.setVisible(true);
    }

}
