

package exameninterfjorgecalero;



public class ExamenInterfJorgeCalero {

   
    public static void main(String[] args) {
        ReservaVacaciones g = new ReservaVacaciones();
        g.setResizable(false);
        g.setLocationRelativeTo(null);
        g.setVisible(true);
    }
    
    
    //Si quisieramos insertar nuestro propio icono utilizariamos el siguiente metodo
//    public Image getIconImage(){
//        Image miIcono = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("imgs/harold.jpeg"));
//        return miIcono;
//    }

}
