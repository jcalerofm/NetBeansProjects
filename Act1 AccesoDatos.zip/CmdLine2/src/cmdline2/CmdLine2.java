
package cmdline2;


public class CmdLine2 {

    
    public static void main(String[] args) {
      
        String Dir = System.getProperty("user.dir");
        System.out.println("Directorio actual: " + Dir);

    }

}
