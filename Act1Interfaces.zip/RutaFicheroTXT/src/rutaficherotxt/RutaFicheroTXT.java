
package rutaficherotxt;


public class RutaFicheroTXT {

    
    public static void main(String[] args) {
        filechooser f = new filechooser();
        f.setVisible(true);
    }
    
    
}
