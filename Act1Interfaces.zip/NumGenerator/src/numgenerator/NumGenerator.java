
package numgenerator;


public class NumGenerator {

   
    public static void main(String[] args) {
        generanumero g = new generanumero();
        g.setVisible(true);
    }
    
}
