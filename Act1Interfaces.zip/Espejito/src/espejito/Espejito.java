
package espejito;


public class Espejito {

   
    public static void main(String[] args) {
       Espejo esp = new Espejo();
       esp.setVisible(true);
    }
    
}
